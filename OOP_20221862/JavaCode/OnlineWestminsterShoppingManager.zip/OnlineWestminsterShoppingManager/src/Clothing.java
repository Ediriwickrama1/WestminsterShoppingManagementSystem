// Define a class named Clothing that extends the Product class
public class Clothing extends Product{
    // Declare additional instance variables
    private String colour;
    private String size;

    //Parameterized Constructor
    public Clothing(String product_ID,String product_Name,int available_Items,String category,double price,String colour,String size){
        super(product_ID,product_Name,available_Items,category,price); // Call the constructor of the superclass (Product) to initialize common attributes
        this.colour = colour;
        this.size = size;
    }

    // Override the toString method to provide a string representation of the Clothing object
    @Override
    public String toString() {
        return "Clothing{" +
                "Product_id = '" + getProduct_ID() + '\'' +
                ", Product_name = '" + getProduct_Name() + '\'' +
                ", available_items = " + getAvailable_Items() +
                ", price = " + getPrice() + ", Colour = '" + colour + '\'' +  " , Size  = '" + size + '\'' +
                '}';
    }
    //getters and setters
    public String getColour() {
        return colour;
    }

    public String getSize() {
        return size;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public void setSize(String size) {
        this.size = size;
    }
}

