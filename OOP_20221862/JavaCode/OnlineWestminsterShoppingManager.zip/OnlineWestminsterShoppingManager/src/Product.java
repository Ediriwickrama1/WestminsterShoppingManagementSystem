// Define a public abstract class named Product
public abstract class Product {
    // Declare private instance variables to represent product attributes
    private String product_ID;
    private String product_Name;
    private int available_Items;
    private String category;
    private double price;

    //Parameterized Constructor
    public Product(String product_ID,String product_Name,int available_Items,String category,double price){
        this.product_ID = product_ID;
        this.product_Name = product_Name;
        this.available_Items = available_Items;
        this.category = category;
        this.price = price;

    }

    // Override the toString method to provide a string representation of the object
    @Override
    public String toString() {
        return "Product{" +
                "Product_id='" + product_ID + '\'' +
                ", Product_name='" + product_Name + '\'' +
                ", available_items=" + available_Items +
                ", price=" + price +
                '}';
    }
    //getters and setters
    public String getProduct_ID() {
        return product_ID;
    }
    public String getProduct_Name() {
        return product_Name;
    }
    public int getAvailable_Items() {
        return available_Items;
    }
    public String getCategory(){return category;}
    public double getPrice(){return price;}

    public void setProduct_ID(String Product_id) {
        this.product_ID = Product_id;
    }
    public void setProduct_Name(String Product_name) {
        this.product_Name = Product_name;
    }
    public void setAvailable_Items(int Num_ava_items) {
        this.available_Items = Num_ava_items;
    }

    public void setCategory(String Category) {this.category = Category;}

    public void setPrice(double price) {
        this.price = price;
    }
}

