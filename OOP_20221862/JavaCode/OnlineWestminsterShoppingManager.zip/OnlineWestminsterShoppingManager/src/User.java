public class User {
    private String userName;
    private String password;
    //default constructor
    public User(){
    }
    //Parameterised constructor
    public User(String username,String password){
        this.userName = username;
        this.password = password;
    }

    //getters and setters
    public String getPassword() {
        return password;
    }
    public String getUserName() {
        return userName;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
}

