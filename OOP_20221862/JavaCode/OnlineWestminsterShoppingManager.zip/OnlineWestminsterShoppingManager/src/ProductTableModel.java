import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

// creating a custom table model
public class ProductTableModel extends AbstractTableModel   {
    // ArrayList to store a collection of Product objects
    private final ArrayList<Product> product_arr3;

    // Column names for the table
    private final String[] columnNames = {"Product_ID", "Name","Category","Price", "Info"};

    // Constructor
    public ProductTableModel(ArrayList<Product> product_arr3) {
        this.product_arr3 = product_arr3;
    }

    // getters
    @Override
    public int getRowCount() {
        return product_arr3.size();
    }


    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Product product = product_arr3.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return product.getProduct_ID();
            case 1:
                return product.getProduct_Name();
            case 2:
                return product.getCategory();
            case 3:
                return product.getPrice();
            case 4:
                if (product.getCategory().equals("Electronics")) {
                    Electronics electronicsProduct = (Electronics) product;
                    return electronicsProduct.getBrand() + ", " + electronicsProduct.getWarranty();
                } else if (product.getCategory().equals("Clothing")) {
                    Clothing clothingProduct = (Clothing) product;
                    return clothingProduct.getColour() + ", " + clothingProduct.getSize();
                } else {
                    return null;
                }
            default:
                return null;
        }
    }
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}




