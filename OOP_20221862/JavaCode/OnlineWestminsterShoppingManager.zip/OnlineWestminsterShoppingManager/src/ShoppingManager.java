// Interface defining methods for managing a shopping system
interface ShoppingManager {
    void add_New_Product();
    void delete_product();
    void product_list();
    void save_file();
    void load_file();
}
