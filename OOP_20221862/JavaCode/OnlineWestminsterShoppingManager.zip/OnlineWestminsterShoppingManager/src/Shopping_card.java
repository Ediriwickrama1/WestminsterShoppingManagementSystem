import java.util.ArrayList;
import java.util.List;

// Class representing a shopping cart that can hold a list of products
class Shopping_cart {
    public List<Product> products_arr;    // List to store the products in the shopping cart

    // Constructor to initialize an empty shopping cart
    public Shopping_cart(){
        this.products_arr = new ArrayList<>();
    }

    // Method to add a product
    public void add_Product(Product product){
        products_arr.add(product);
    }

    // Method to remove a specific product
    public void remove_Products(Product product){
        products_arr.remove(product);
    }
    public double totalCost(){
        double total_cost = 0;
        for(Product product : products_arr){
            total_cost += product.getPrice();
        }
        return total_cost;
    }

    public List<Product> getProducts() {
        return products_arr;
    }


}

