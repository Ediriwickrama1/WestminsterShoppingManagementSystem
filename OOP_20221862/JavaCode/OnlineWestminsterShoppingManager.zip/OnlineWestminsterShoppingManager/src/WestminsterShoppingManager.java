import java.io.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.FileReader;

// Class implementing the ShoppingManager interface for Westminster Shopping Manager
public class WestminsterShoppingManager implements ShoppingManager {
    @Override
    public String toString() {
        return "WestminsterShoppingManager{" +
                "product_arr2=" + added_Items_List +
                '}';
    }

    ArrayList<Product> added_Items_List;  // List to store the added items (products)
    private ShoppingManagerGUI shoppingManagerGUI; // Instance of ShoppingManagerGUI for GUI representation

    // Constructor to initialize the WestminsterShoppingManager
    public WestminsterShoppingManager(){
        this.added_Items_List = new ArrayList<Product>();this.shoppingManagerGUI = new ShoppingManagerGUI();  this.shoppingManagerGUI.setProducts(added_Items_List);
    }

    // Method to add a new product to the system
    public void add_New_Product() {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Please Enter item type (Clothing or Electronics): ");
            String itemType = scanner.next().toLowerCase();

            if (itemType.equals("electronics")) {
                addElectronicsProduct(scanner);
            } else if (itemType.equals("clothing")) {
                addClothingProduct(scanner);
            } else {
                System.out.println("Invalid input");
            }

            // After adding the new product, sort the list
            Collections.sort(added_Items_List, Comparator.comparing(Product::getProduct_ID));

        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }


    private void addElectronicsProduct(Scanner scanner) {
        System.out.print("Please enter product id: ");
        String product_ID = scanner.next();
        System.out.print("Please enter product name: ");
        String product_Name = scanner.next();
        System.out.print("Please enter number of available products: ");
        int available_Items = scanner.nextInt();
        System.out.print("Please enter Product Category: ");
        String category = scanner.next();
        System.out.print("Please enter product price: ");
        double price = scanner.nextDouble();
        System.out.print("Please Enter brand name of the electronic item: ");
        String brand = scanner.next();
        System.out.print("Please Enter the warranty period in months: ");
        int warranty = scanner.nextInt();

        Electronics electronics = new Electronics(product_ID, product_Name, available_Items, category, price, brand, warranty);
        added_Items_List.add(electronics);
        System.out.println("Electronics item added successfully");
    }

    private void addClothingProduct(Scanner scanner) {
        System.out.print("Please Enter product id: ");
        String Product_id = scanner.next();
        System.out.print("Please Enter product name: ");
        String Product_name = scanner.next();
        System.out.print("Please Enter number of products available: ");
        int available_Items = scanner.nextInt();
        System.out.print("Please Enter Product Category: ");
        String category = scanner.next();
        System.out.print("Please Enter item price: ");
        double price = scanner.nextDouble();
        System.out.print("Please Enter cloth color: ");
        String colour = scanner.next();
        System.out.print("Please Enter cloth size: ");
        String size = scanner.next();

        Clothing clothing = new Clothing(Product_id, Product_name, available_Items, category, price, colour, size);
        added_Items_List.add(clothing);
        System.out.println("Clothing item added successfully");
    }

    // Method to delete a product
    public void delete_product() {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please enter product id of removable item: ");
            String removeId = scanner.next();

            for (Product product : added_Items_List) {
                if (Objects.equals(product.getProduct_ID(), removeId)) {
                    System.out.println("Removed item details: " +
                            "Product_id: " + product.getProduct_ID() +
                            ", Product_name: " + product.getProduct_Name() +
                            ", Product_Category: " + product.getCategory());

                    added_Items_List.remove(product);
                    System.out.println(product.getCategory() + " Product removed Successfully");
                    return; // Exit the loop once the product is found and removed
                }
            }

            // If the loop completes without finding the product
            System.out.println("No product found with the given product id.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // Method to display the product list
    @Override
    public void product_list() {
        try {
            System.out.println(" ============== Electronics Items ============= ");
            for (int i = 0; i < added_Items_List.size(); i++) {
                if(Objects.equals(added_Items_List.get(i).getCategory(), "Electronics")){
                    Collections.sort(added_Items_List, (p1, p2) -> p1.getProduct_ID().compareTo(p2.getProduct_ID()));
                    System.out.println( added_Items_List.get(i));}
            }
            System.out.println(" =============== Clothing Items ================");

            for(int i = 0; i < added_Items_List.size(); i++){
                if(Objects.equals(added_Items_List.get(i).getCategory(), "Clothing")){
                    Collections.sort(added_Items_List, (p1, p2) -> p1.getProduct_ID().compareTo(p2.getProduct_ID()));
                    System.out.println( added_Items_List.get(i));}
            }
        }catch (Exception e) {
            System.out.println(e);
        }}

    // Method to load data from a file
    @Override
    public void load_file() {
        try {
            BufferedReader shop_cart = new BufferedReader(new FileReader("C:\\Users\\Samadhi\\IdeaProjects\\OnlineWestminsterShoppingManager\\src\\shop_cart.txt"));
            String read;
            while ((read = shop_cart.readLine()) != null) {
                System.out.println(read);
            }
            shop_cart.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // Method to save data to a file
    @Override
    public void save_file() {
        try {
            BufferedWriter shop_cart = new BufferedWriter(new FileWriter("C:\\Users\\Samadhi\\IdeaProjects\\OnlineWestminsterShoppingManager\\src\\shop_cart.txt"));
            shop_cart.write(" ******  Electronics product Items List ****** ");
            shop_cart.newLine();
            shop_cart.newLine();
            for (int i = 0; i < added_Items_List.size(); i++) {
                if(Objects.equals(added_Items_List.get(i).getCategory(), "Electronics")){
                    shop_cart.write(added_Items_List.get(i).toString());
                    shop_cart.newLine();
                }}
            shop_cart.write(" ******  Clothing product Items List ****** ");
            shop_cart.newLine();
            shop_cart.newLine();
            for (int i = 0; i < added_Items_List.size(); i++) {
                if(Objects.equals(added_Items_List.get(i).getCategory(), "Clothing")){
                    shop_cart.write(added_Items_List.get(i).toString());
                    shop_cart.newLine();
                }}
            shop_cart.close();
            System.out.println("File saved Successfully");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // Method to display the console menu
    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        int option;
        while (true) {
            // Print scanner lists
            System.out.println("============== Welcome to the online Shopping ===============");
            System.out.println("Console menu");
            System.out.println("1) Add a new item");
            System.out.println("2) Delete a item");
            System.out.println("3) Show product list");
            System.out.println("4) Save to file");
            System.out.println("5) Load file");
            System.out.println("6) Load GUI");
            System.out.println("7) Quit");

            System.out.print("Please enter the option: ");
            option = scanner.nextInt();

            if (option == 1) {
                if (added_Items_List.size() <= 50) {
                    add_New_Product();
                } else {
                    System.out.println("You can't add another item");
                }
            } else if (option == 2) {
                delete_product();

            } else if (option == 3) {
                product_list();

            } else if (option == 4) {
                save_file();
            } else if (option == 5) {
                load_file();
            } else if (option == 7) {
                System.out.println("Thank you visit again");
                System.exit(0);
            } else if (option == 6) {

                shoppingManagerGUI.setVisible(true);
                shoppingManagerGUI.setProducts(added_Items_List);
            } else {
                System.out.println("Invalid input");
            }
        }
    }

    // Main method to run the Westminster Shopping Manager
    public static void main(String[] args) {

        WestminsterShoppingManager wsm=new WestminsterShoppingManager();
        wsm.showMenu();

    }
}

