// Define a class named Electronics that extends the Product class
public class Electronics extends Product {

    // Declare additional instance variables
    private String brand;
    private int warranty;

    //Parameterised constructor
    public Electronics(String product_ID,String product_Name,int available_Items,String category,double price,String brand,int warranty){
        super(product_ID,product_Name,available_Items,category,price); // Call the constructor of the superclass (Product) to initialize common attributes
        this.brand = brand;
        this.warranty = warranty;
    }
    // Override the toString method to provide a string representation of the Electronics object
    @Override
    public String toString() {
        return "Electronics{" +
                "Product_id = '" + getProduct_ID() + '\'' +
                ", Product_name = '" + getProduct_Name() + '\'' +
                ", available_items = " + getAvailable_Items() +
                ", price = " + getPrice() + ", Product_Brand = '" + brand + '\'' +  ", Warranty_Period = '" + warranty + '\'' +
                '}';
    }

    // getters and setters
    public String getBrand() {
        return brand;
    }

    public int getWarranty() {
        return warranty;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setWarranty(int warranty) {
        this.warranty = warranty;
    }
}

