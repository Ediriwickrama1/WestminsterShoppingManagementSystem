import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// GUI class for the Shopping Manager application
public class ShoppingManagerGUI extends JFrame {
    private List<Product> list_Of_Products;   // List to store the products available in the shopping system
    private JComboBox<String> type_Of_Product; //selecting the type of product to display
    private JTable table_Of_Products; //displaying the list of products
    private JTextArea product_Details_Text;   //displaying details of the selected product
    private JButton add_To_Cart;  //adding a product
    private JButton view_Shopping_Cart;   //viewing the shopping cart
    private Shopping_cart shopping_Cart;   //manage added products

    // Constructor for the ShoppingManagerGUI class
    public ShoppingManagerGUI() {
        this.list_Of_Products = new ArrayList<>();
        this.shopping_Cart = new Shopping_cart();

        setTitle("West Minister Shopping Manager");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize components and set up the layout
        InitiateComponents();
        createProductTable();

        setLayout(new BorderLayout());
        add(TopPanel(), BorderLayout.NORTH);
        add(TablePanel(), BorderLayout.CENTER);
        add(ProductDetails(), BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);


    }

    // Method to initialize the GUI components
    private void InitiateComponents() {
        type_Of_Product = new JComboBox<>(new String[]{"All", "Electronics", "Clothing"});
        table_Of_Products = new JTable();
        product_Details_Text = new JTextArea(10, 50);
        add_To_Cart = new JButton("Add To Cart");
        view_Shopping_Cart = new JButton("View Shopping Cart");

        add_To_Cart.setEnabled(false);
        view_Shopping_Cart.addActionListener(e -> showShoppingCart());
    }

    // Method to create the top panel containing product category selection and view shopping cart button
    private JPanel TopPanel() {
        JPanel panel = new JPanel();
        JPanel SelectPanel = new JPanel();
        SelectPanel.add(new JLabel("Select Product Category"));
        SelectPanel.add(type_Of_Product);

        panel.add(SelectPanel, BorderLayout.CENTER);

        JPanel AddToShoopingPanel = new JPanel();
        AddToShoopingPanel.add(view_Shopping_Cart);

        panel.add(AddToShoopingPanel, BorderLayout.WEST);

        type_Of_Product.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTable();
            }
        });

        return panel;


    }

    // Method to create the panel containing the product table
    private JPanel TablePanel() {
        JPanel panel = new JPanel();
        panel.add(new JScrollPane(table_Of_Products));
        return panel;
    }

    // Method to create the panel containing product details and add to cart button
    private JPanel ProductDetails() {
        JPanel panel = new JPanel();

        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.add(new JLabel("Selected Product-Details"));
        detailsPanel.add(new JScrollPane(product_Details_Text));
        panel.add(detailsPanel, BorderLayout.CENTER);

        JPanel addToCartPanel = new JPanel();
        addToCartPanel.add(add_To_Cart);
        panel.add(addToCartPanel, BorderLayout.SOUTH);

        add_To_Cart.addActionListener(e -> addToShoppingCart());

        return panel;
    }

    // Method to create the product table
    private void createProductTable() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return String.class; // Use String class for all columns
            }
        };

        model.addColumn("Product ID");
        model.addColumn("Name");
        model.addColumn("Available Items");
        model.addColumn("Category");
        model.addColumn("Price(€)");
        model.addColumn("Info");

        table_Of_Products.setModel(model);

        table_Of_Products.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        table_Of_Products.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component renderer = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                int availableItemsColumnIndex = 2;
                int availableItems = Integer.parseInt(table.getValueAt(row, availableItemsColumnIndex).toString());

                if (availableItems < 3) {
                    renderer.setForeground(Color.RED);
                } else {
                    renderer.setForeground(table.getForeground());
                }

                return renderer;
            }
        });

        table_Of_Products.getSelectionModel().addListSelectionListener(e -> {
            int row = table_Of_Products.getSelectedRow();
            add_To_Cart.setEnabled(row != -1);

            if (row != -1) {
                String pid = table_Of_Products.getValueAt(row, 0).toString();
                Product selectedProduct = findProByID(pid);

                if (selectedProduct != null) {
                    String detail = "Product ID: " + selectedProduct.getProduct_ID() + "\n" +
                            "Category: " + selectedProduct.getCategory() + "\n" +
                            "Items Available: " + selectedProduct.getAvailable_Items() + "\n" +
                            "Price(): " + selectedProduct.getPrice();

                    if (selectedProduct instanceof Electronics) {
                        Electronics electronics = (Electronics) selectedProduct;
                        detail += "\nBrand: " + electronics.getBrand() + "\n" +
                                "Warranty Period: " + electronics.getWarranty() + " months";
                    } else if (selectedProduct instanceof Clothing) {
                        Clothing clothing = (Clothing) selectedProduct;
                        detail += "\nSize: " + clothing.getSize() + "\n" +
                                "Color: " + clothing.getColour();
                    }

                    product_Details_Text.setText(detail);
                }
            } else {
                product_Details_Text.setText("");
            }
        });
    }

    // Method to update the product table based on the selected product category
    private void updateTable()
    {
        DefaultTableModel model=(DefaultTableModel) table_Of_Products.getModel();
        model.setRowCount(0);

        String selType=(String) type_Of_Product.getSelectedItem() ;

        list_Of_Products.sort(Comparator.comparing(Product::getProduct_ID));

        for (Product product : list_Of_Products)
        {
            if(selType.equals("All") || (selType.equals("Electronics") && product instanceof Electronics) ||
                    (selType.equals("Clothing") && product instanceof Clothing))
            {


                String info="";

                if(product instanceof Electronics)
                {
                    Electronics electronics=(Electronics) product;
                    info =electronics.getBrand()+","+electronics.getWarranty();
                }
                else if (product instanceof Clothing)
                {
                    Clothing clothing =(Clothing) product;
                    info=clothing.getColour()+","+clothing.getSize();
                }
                Object[] row={product.getProduct_ID(), product.getProduct_Name(),product.getAvailable_Items(), product.getCategory(),
                        String.format("%.2f", product.getPrice()),info,
                        (product instanceof Electronics)? "Electronics" : "Clothing"};
                model.addRow(row);
            }
        }

        add_To_Cart.setEnabled(false);
        product_Details_Text.setText("");

    }


    // Method to add a selected product
    private void addToShoppingCart()
    {
        int row= table_Of_Products.getSelectedRow();

        if(row != -1)
        {
            String id= table_Of_Products.getValueAt(row,0).toString();
            Product productSelected=findProByID(id);

            if (productSelected.getAvailable_Items()>0)
            {
                productSelected.setAvailable_Items(productSelected.getAvailable_Items() -1);
                shopping_Cart.add_Product(productSelected);
                JOptionPane.showMessageDialog(this,"Product is successfully added to cart");
                updateProTable();
            }
            else
            {
                JOptionPane.showMessageDialog(this,"Product is not added");

            }
        }
    }

    // Method to display the shopping cart details
    private void showShoppingCart()
    {
        DefaultTableModel cart= new DefaultTableModel();
        cart.addColumn("Product");
        cart.addColumn("Quantity");
        cart.addColumn("Price");

        for(Product product: shopping_Cart.getProducts())
        {
            Object[] rowCart={product.getProduct_Name(),1, product.getPrice()};
            cart.addRow(rowCart);
        }


        JTable cTable=new JTable(cart);
        JScrollPane cartScroll = new JScrollPane(cTable);

        double total= shopping_Cart.totalCost();
        double finalprice= calculate_Final_Cost();

        JPanel cDetails=new JPanel(new BorderLayout());
        cDetails.add(cartScroll, BorderLayout.CENTER);

        JPanel totalDiscount=new JPanel(new GridLayout(6,2));
        totalDiscount.add(new JLabel("Total "));
        JLabel totalCost=new JLabel(String.valueOf(total));
        totalCost.setHorizontalAlignment(SwingConstants.RIGHT);
        totalDiscount.add(totalCost);


        if(finalprice < total)
        {
            double firstDiscont=total*0.1;
            totalDiscount.add(new JLabel("First Purchase Discount (10%) "));
            JLabel firstPurchase=new JLabel(String.valueOf(firstDiscont));
            firstPurchase.setHorizontalAlignment(SwingConstants.RIGHT);
            totalDiscount.add(firstPurchase);

        }

        if (shopping_Cart.getProducts().size()>=3)
        {
            double catergoryDis=total*0.2;
            totalDiscount.add(new JLabel("Three Items In Same Category Discount(20%)"));
            JLabel cdl=new JLabel("-"+catergoryDis);
            cdl.setHorizontalAlignment(SwingConstants.RIGHT);
            totalDiscount.add(cdl);
        }

        totalDiscount.add(new JLabel("Final Total "));
        JLabel finalPrice=new JLabel(String.valueOf(finalprice));
        finalPrice.setHorizontalAlignment(SwingConstants.RIGHT);
        totalDiscount.add(finalPrice);

        JFrame cartDetail=new JFrame("Shopping Cart");
        cartDetail.setLayout(new BorderLayout());
        cartDetail.add(cDetails, BorderLayout.CENTER);

        cartDetail.add(totalDiscount,BorderLayout.SOUTH);
        cartDetail.setSize(400,400);
        cartDetail.setLocationRelativeTo(null);
        cartDetail.setVisible(true);
    }

    // Method to update the product table
    private void updateProTable()
    {

    }

    // Method to calculate the final cost with discounts
    private double calculate_Final_Cost()
    {
        double total= shopping_Cart.totalCost();
        double finalprice=total;

        if(shopping_Cart.getProducts().size()>=3)
        {
            finalprice*=0.8;
        }
        if(total>0)
        {
            finalprice*=0.9;
        }
        return finalprice;

    }

    // Method to find a product by its ID
    private Product findProByID(String pid) {
        return list_Of_Products.stream()
                .filter(product -> pid != null && pid.equals(product.getProduct_ID()))
                .findFirst()
                .orElse(null);
    }

    // Method to set the initial list of products in the GUI
    public void setProducts(List<Product> productList)
    {
        this.list_Of_Products =productList;
        updateTable();
    }
}



